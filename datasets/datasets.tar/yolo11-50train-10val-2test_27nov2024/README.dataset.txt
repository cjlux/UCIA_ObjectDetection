# UCIA-IA: Object Detection > 50 train - 10 val - 2 test
https://universe.roboflow.com/ucia/ucia-ia-object-detection

Provided by a Roboflow user
License: undefined

