# UCIA-IA: Object Detection v2.0 > 2024-12-09 10:23pm
https://universe.roboflow.com/ucia/ucia-ia-object-detection-v2.0

Provided by a Roboflow user
License: CC BY 4.0

